create
    definer = gafa@`%` procedure REGISTRARHOLA(IN hello varchar(10))
INSERT INTO HOLA (HHola)
		VALUES (hello);

