create
    definer = gafa@`%` procedure REGISTRAR_CLIENTE(IN Pnombre varchar(30), IN Papellido varchar(30),
                                                   IN Sapellido varchar(30), IN Iprovincia varchar(30),
                                                   IN Ccanton varchar(30), IN Correo1 varchar(30),
                                                   IN Correo2 varchar(30), IN Telefono varchar(10), IN Foto varchar(30),
                                                   IN Ccontrasena varchar(8), IN Ddescripcion varchar(300),
                                                   IN Fecha date)
BEGIN
	INSERT INTO USUARIO (Primer_nombre, Primer_apellido, Segundo_apellido, Id_rol, Email_1, Contrasena, Foto_perfil, Id_estado)
	VALUES
		(Pnombre, Papellido, Sapellido, 2, Correo1, Ccontrasena, Foto, 1);

	SELECT @id_usuario := Id_usuario FROM USUARIO WHERE Email_1 = Correo1;
	SELECT @id_province := Id_provincia FROM PROVINCIA WHERE Nombre = Iprovincia;
	
	INSERT INTO CLIENTE (Id_cliente, Telefono_movil, Id_provincia, Canton, Email_2, Descripcion, Fecha_Inscripcion)
	VALUES
		(@id_usuario, Telefono, @id_province, Ccanton, Correo2, Ddescripcion, Fecha);
END;

