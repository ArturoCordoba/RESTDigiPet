create
    definer = gafa@`%` procedure INSERTAR_PAGO_CLIENTE(IN Icliente int, IN Pago varchar(30))
BEGIN
	INSERT INTO PAGO_X_CLIENTE (Id_cliente, Metodo_pago)
	VALUES
		(Icliente, Pago);
END;

