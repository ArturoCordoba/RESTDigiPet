create
    definer = gafa@`%` procedure REGISTRAR_CUIDADOR(IN Pnombre varchar(30), IN Papellido varchar(30),
                                                    IN Sapellido varchar(30), IN Iprovincia varchar(30),
                                                    IN Ccanton varchar(30), IN Iuniversidad varchar(50),
                                                    IN Ccarne varchar(10), IN Correo1 varchar(30),
                                                    IN Correo2 varchar(30), IN Telefono varchar(10),
                                                    IN Foto varchar(30), IN Ccontrasena varchar(8),
                                                    IN Ddescripcion varchar(300), IN Op_provincia tinyint(1),
                                                    IN Fecha date)
BEGIN
	INSERT INTO USUARIO (Primer_nombre, Primer_apellido, Segundo_apellido, Id_rol, Email_1, Contrasena, Foto_perfil, Id_estado)
	VALUES
		(Pnombre, Papellido, Sapellido, 3, Correo1, Ccontrasena, Foto, 1);
		
	SELECT @id_user := Id_usuario FROM USUARIO WHERE Email_1 = Correo1;
	SELECT @id_univer := Id_universidad FROM UNIVERSIDAD WHERE Nombre = Iuniversidad;
	SELECT @id_prov := Id_provincia FROM PROVINCIA WHERE Nombre = Iprovincia;
		
	INSERT INTO CUIDADOR (Id_cuidador, Carne, Telefono_movil, Id_universidad, Canton, Opcion_provincias, Email_2, Descripcion, Fecha_Inscripcion)
	VALUES
		(@Id_user, CCarne, Telefono, @id_univer, CCanton, Op_provincia, Correo2, Ddescripcion, Fecha);
END;

