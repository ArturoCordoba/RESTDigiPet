create
    definer = gafa@`%` procedure REGISTRAR_MASCOTA(IN Icliente int, IN Mnombre varchar(30), IN Rraza varchar(30),
                                                   IN Eedad int, IN Ttamano varchar(2), IN Ddescripcion varchar(300),
                                                   IN Fecha date)
BEGIN
	SELECT @id_tam := Id_tamano FROM TAMANO WHERE Nombre = Ttamano;
	INSERT INTO MASCOTA (Id_cliente, Nombre, Raza, Edad, Id_tamano, Descripcion, Fecha_inscripcion)
	VALUES
		(Icliente, Mnombre, Rraza, Eedad, @id_tam, Ddescripcion, Fecha);
END;

