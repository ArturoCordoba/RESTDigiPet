create
    definer = gafa@`%` procedure INSERTAR_FOTO_MASCOTA(IN Imascota int, IN Foto_masc varchar(30))
BEGIN
	INSERT INTO FOTO_X_MASCOTA (Id_mascota, Foto)
	VALUES
		(Imascota, Foto_masc);
END;

