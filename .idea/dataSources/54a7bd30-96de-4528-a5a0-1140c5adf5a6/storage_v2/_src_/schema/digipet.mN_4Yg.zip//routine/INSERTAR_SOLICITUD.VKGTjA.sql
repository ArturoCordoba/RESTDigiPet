create
    definer = gafa@`%` procedure INSERTAR_SOLICITUD(IN FHora_inicio datetime, IN FHora_final datetime, IN Dduracion int,
                                                    IN Esolicitud varchar(10), IN Precio decimal, IN Icliente int,
                                                    IN Imascota int, IN Iservicio int, IN Icuidador int,
                                                    IN Calif decimal, IN Pago varchar(30), IN Dir varchar(300),
                                                    IN Ddescripcion varchar(300))
BEGIN
	INSERT INTO SOLICITUD (Hora_Inicio, Hora_Final, Duracion, Estado_solicitud, Precio_unitario, Id_cliente, Id_mascota, Id_servicio)
	VALUES
		(FHora_inicio,FHora_final,Dduracion,Esolicitud,Precio,Icliente,Imascota,Iservicio);
	SELECT @Id_sol := Id_solicitud FROM SOLICITUD WHERE Hora_Inicio = FHora_inicio AND Id_cliente = Icliente;
	INSERT INTO SOLICITUD_X_CUIDADOR (Id_solicitud, Id_cuidador, Calificacion, Metodo_pago, Direccion, Descripcion)
	VALUES
		(@Id_sol,Icuidador,Calif,Pago,Dir,Ddescripcion);
END;

