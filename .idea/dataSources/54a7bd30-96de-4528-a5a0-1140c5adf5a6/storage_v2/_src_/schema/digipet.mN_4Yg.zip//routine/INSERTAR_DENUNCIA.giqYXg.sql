create
    definer = gafa@`%` procedure INSERTAR_DENUNCIA(IN Icliente int, IN Icuidador int, IN Ddescripcion varchar(300))
BEGIN
	INSERT INTO DENUNCIA (Id_cliente, Id_cuidador, Descripcion)
	VALUES
		(Icliente,Icuidador,Ddescripcion);
END;

