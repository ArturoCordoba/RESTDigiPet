create
    definer = gafa@`%` procedure INSERTAR_BADGE_CUIDADOR(IN Icuidador int, IN Ibadge int)
BEGIN
	INSERT INTO BADGE_X_CUIDADOR (Id_cuidador, Id_badge)
	VALUES
		(Icuidador,Ibadge);
END;

