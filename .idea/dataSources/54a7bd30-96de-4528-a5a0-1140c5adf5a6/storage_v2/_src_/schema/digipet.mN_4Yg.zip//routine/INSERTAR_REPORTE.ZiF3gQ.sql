create
    definer = gafa@`%` procedure INSERTAR_REPORTE(IN Duration decimal, IN Caca int, IN Orines int, IN Juegos int,
                                                  IN Distance decimal, IN Details varchar(300), IN Isolicitud int)
BEGIN
	INSERT INTO REPORTE (Duracion, Cantidad_caca, Cantidad_orines, Cantidad_juegos, Distancia, Detalles, Id_solicitud)
	VALUES
		(Duration, Caca, Orines, Juegos, Distance, Details, Isolicitud);
END;

