create
    definer = gafa@`%` procedure PRUEBA1(IN ID int, IN CUIDADOR int)
BEGIN
	IF ID = CUIDADOR THEN
		SELECT 'TRUE';
	ELSEIF ID != CUIDADOR THEN
		SELECT 'FALSE';
	END IF;
END;

