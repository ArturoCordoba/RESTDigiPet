create
    definer = gafa@`%` procedure VERHOLA(IN hello varchar(10))
SELECT * FROM HOLA WHERE HHola = hello;

