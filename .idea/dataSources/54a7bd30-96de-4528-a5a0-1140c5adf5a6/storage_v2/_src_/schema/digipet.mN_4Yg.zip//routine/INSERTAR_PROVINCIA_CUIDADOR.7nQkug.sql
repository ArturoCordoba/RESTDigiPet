create
    definer = gafa@`%` procedure INSERTAR_PROVINCIA_CUIDADOR(IN Icuidador int, IN Iprovincia varchar(30))
BEGIN
	SELECT @id_provincia := Id_provincia FROM PROVINCIA WHERE Nombre = Iprovincia;
	INSERT INTO PROVINCIA_X_CUIDADOR (Id_cuidador, Id_provincia)
	VALUES
		(Icuidador,@id_provincia);
END;

