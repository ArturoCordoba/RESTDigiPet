create
    definer = gafa@`%` procedure INSERTAR_FOTO_REPORTE(IN Ireporte int, IN Foto_reporte varchar(30))
BEGIN
	INSERT INTO FOTO_X_REPORTE (Id_reporte, Foto)
	VALUES
		(Ireporte, Foto_reporte);
END;

