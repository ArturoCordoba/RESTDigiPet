create
    definer = gafa@`%` procedure INSERTAR_DISPONIBILIDAD(IN Icuidador int, IN Horainicial datetime, IN Horafinal datetime)
BEGIN
	SELECT @id_keeper1 := Id_cuidador,
			 @id_disp1 := Id_disponibilidad
	FROM DISPONIBILIDAD_X_CUIDADOR
	WHERE (Fecha_hora_final >= Horainicial
		AND Fecha_hora_inicio <= Horainicial 
		AND Fecha_hora_final < Horafinal
		AND Fecha_hora_inicio < Horafinal) 
		AND Id_cuidador = Icuidador;
	
	SELECT @id_keeper2 := Id_cuidador,
		    @id_disp2 := Id_disponibilidad
	FROM DISPONIBILIDAD_X_CUIDADOR
	WHERE (Fecha_hora_inicio > Horainicial
		AND Fecha_hora_final > Horainicial 
		AND Fecha_hora_inicio <= Horafinal
		AND Fecha_hora_final >= Horafinal) 
		AND Id_cuidador = Icuidador;
	
	IF @id_keeper1 = Icuidador THEN
		UPDATE DISPONIBILIDAD_X_CUIDADOR
		SET Fecha_hora_final = Horafinal
		WHERE Id_disponibilidad = @id_disp1;	
	ELSEIF @id_keeper2 = Icuidador THEN
		UPDATE DISPONIBILIDAD_X_CUIDADOR
		SET Fecha_hora_inicio = Horainicial
		WHERE Id_disponibilidad = @id_disp2;
	ELSE
		INSERT INTO DISPONIBILIDAD_X_CUIDADOR (Id_cuidador, Fecha_hora_inicio, Fecha_hora_final)
		VALUES
			(Icuidador, Horainicial, Horafinal);
	END IF;
		
END;

